# POPOTI Align Helper

More friendly alignment based on observation perspective<br>
![](image/preview.jpeg)

# v1.1.0
## Add

- Distribution alignment mode Add alignment by interval distance<br>
  The moving object will be fixed, and the distance between other objects and the moving object will be adjusted (bounding box)

- Preferences can set whether to display button text<br>
  ![not_show_text_button.png](image/not_show_text_button.png)

Align Mode:<br>

- World Original:Aligning to the world origin is the same as resetting <br>

- Active:Align to Active Object<br>

- Cursor:Align to Cursor(Scale reset 1)<br>

- Ground:Align Ground<br>

- Distribution:Distribution Align<br>

- Align:General alignment, you can set the alignment of each axis(maximum, center, minimum)<br>
