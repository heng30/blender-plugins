TODO  

major  
- [ ] rename images change ui list order and texture won't update  
- [ ] reload warning update and reset it when last version installed during this blender session  

minor  
- [ ] add unpack operator to Readme file  
- [ ] more obvious timer warning  
- [ ] update uninstaller disclaimer (rewrite dialog popup op)  
- [ ] rename libs change ui list order  
- [ ] user number and fake user for inspectors  
- [ ] link images should not be able to be deleted (?)  
- [ ] reveal and modify image buttons in uv/image editor and image texture node  
- [ ] size of image preview  
- [ ] direct link to donate  
- [ ] reload vse strips logic  
- [ ] debug lib to reload when linking  
- [ ] reload udim tiles images  
- [ ] important reports  
- [ ] select file in linux explorer when revealing it  
- [ ] check reveal in explorer on mac os  
- [ ] unpacking options for images  

v2.0.2  
- [x] ko fi link  
- [x] unpack button for images  
- [x] fix special characters in reveal files windows  
- [x] emboss false for remove images op when packed image  

v2.0.1  
- [x] packed files images (missing)  
- [x] when removing image, reload texture  
- [x] addon update warning top of the topbar menu  
- [x] fix addon updater  

v2.0.0  
- [x] readme  
- [x] better readbility in ui list (when something has to be reload or missing)  
- [x] preview images  
- [x] proper indentation in addon_prefs.py  
- [x] better executable check (startup ?)  
- [x] catch unfound file when opening and modifying  
- [x] open library  
- [x] ui list lib keep reload button grayed out  
- [x] bug when removing images used in displace texture  
- [x] remove libraries  
- [x] reveal file in explorer bug in linux  
- [x] validation on save and revert operator  
