from . import ops
from . import preferences
from . import property
from . import server
from . import src
from . import ui
from . import timer

module_list = (
    property,
    src,
    ops,
    preferences,
    server,
    ui,
    timer,
)


def register():
    for module in module_list:
        module.register()


def unregister():
    for module in module_list:
        module.unregister()
