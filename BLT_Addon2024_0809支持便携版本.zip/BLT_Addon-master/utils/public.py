import bpy
from os.path import dirname, realpath
from . import ADDON_NAME

ADDON_FOLDER = dirname(dirname(realpath(__file__)))


def get_pref():
    return bpy.context.preferences.addons[ADDON_NAME].preferences
