from ..utils.icons import Icons


def register():
    Icons.register()


def unregister():
    Icons.unregister()
