# SimpleDeformHelper

Simple Deform Modifier Visual adjustment tool

You can modify parameters more intuitively by dragging the gizmo directly

![emm.jpeg](image/emm.jpeg)

显示Gizmo需要选择活动物体并且活动修改器为简易形变修改器

1.角度控制Gizmo

    可通过拖动来控制修改器的值

2.轴向控制Gizmo

    通过单击修改活动修改器的形变轴向

快捷键(在拖动Gizmo时):

    X Y Z:修改修改器的变形轴

A:显示变形轴Gizmo

    滚轮滚动:切换原点控制模式

切换轴向Gizmo(只有在模式为弯曲时才可显示):

    6个方向每个方向有两个方向可切换

在拖动上下限Gizmo时可以按住Ctrl 保持上下限之间的相对距离