data = {
    "Place": "放置",
    "Transform Pro": "变换加强版",
    "Dynamic Place": "动态放置",
    "Stop When Intersecting": "碰撞时候停止",
    "Keep Color When Intersecting": "碰撞时不变颜色",
    "Collision Alert": "碰撞警告",
    "Invert Axis": "反转轴",
    "Trace Collection Level": "追溯父级集合深度",
    "Draw Active Collision": "绘制激活项目碰撞",
    "Draw Active Object Collision lines, Performance will decrease": "绘制激活项目碰撞线，性能会下降",
    "Scale\nShift: Duplicate\nAlt: Set Axis": "缩放\nShift: 复制\nAlt: 设置轴",
    "Rotate\\nShift: Duplicate\\nAlt: Set Axis": "旋转\nShift: 复制\nAlt: 设置轴",
    "Please select the active object": "请选择一个物体为激活项",
    "Use Color When Moving": "运行时变色",
    "Gizmo Handle All Event": "Gizmo 接收所有按键",
    "Active Instance Bounding Box": "活动项实例碰撞盒",
    "Consider Scene Geo Nodes Instance": "评估场景几何节点实例",
    "Use visual obj bounding box, slower": "使用可视化物体碰撞盒，速度慢一些",
    "Use basic mesh bounding box, faster": "使用基础网格碰撞盒，速度快一些",
    "Scene Objects": "场景物体",

    "Set Place Axis": "设置放置轴"

}
