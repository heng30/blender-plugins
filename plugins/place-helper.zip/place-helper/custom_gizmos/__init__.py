from . import gz

def register():
    gz.register()

def unregister():
    gz.unregister()