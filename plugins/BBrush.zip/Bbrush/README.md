这是一个模拟类似ZBrush雕刻方式的插件<br>
[演示视频](https://www.bilibili.com/video/BV1zY4y1D732/)

# 更新日志

### v1.1.0

    添加了快捷键显示
    添加了新的快捷键 SHIFT+左键 在空白区域拖拽  倾斜视图
    修复了临时文件夹不存在导致log无法写入
    删除了深度采样值设置

# 快捷键

快捷键已包含在插件中,可直接在Bl中查看
鼠标放在深度图上拖动可缩放

[tip 多级细分后切换隐藏面将失效](https://projects.blender.org/blender/blender/issues/95419)
