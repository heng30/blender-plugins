import os

ICON_PATH = os.path.join(os.path.dirname(__file__), 'icon')
